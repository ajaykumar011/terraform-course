# This program prints Testing!

print('Testing!')